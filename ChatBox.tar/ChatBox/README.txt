//////////// CHATBOX ///////////////////


// OllyDev //


// open source //

## links ##

GitHub:
      https://github.com/Zyphon-22/ChatBox
      
itch.io:
       https://ollydev.itch.io/chatbox


link to python download:
                       https://www.python.org/downloads/
                       
if socket and threading isnt installed:

pip install socket
pip install threading

/// or ///

pip3 install socket
pip3 install threading

// MUST HAVE PYTHON 3.7.5 + //

